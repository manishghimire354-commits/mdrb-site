import React from "react";

function Header({ cartCount }) {
  return (
    <header className="bg-green-600 text-white p-4 flex justify-between items-center">
      <h1 className="text-xl font-bold">MDRB Suppliers</h1>
      <div>
        Cart: <span className="font-bold">{cartCount}</span>
      </div>
    </header>
  );
}

export default Header;