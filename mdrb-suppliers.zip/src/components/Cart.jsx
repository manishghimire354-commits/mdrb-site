import React from "react";

function Cart({ cart, removeFromCart }) {
  const total = cart.reduce((acc, item) => acc + item.price, 0);

  return (
    <aside className="bg-white shadow p-4 mt-6 mx-6 rounded">
      <h2 className="text-lg font-bold mb-2">Cart</h2>
      {cart.length === 0 ? (
        <p>No items in cart</p>
      ) : (
        <ul>
          {cart.map((item, idx) => (
            <li key={idx} className="flex justify-between items-center mb-2">
              <span>{item.name} - Rs. {item.price}</span>
              <button
                onClick={() => removeFromCart(idx)}
                className="text-red-600 hover:underline"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-4 font-bold">Total: Rs. {total}</p>
      <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 w-full">
        Checkout (Demo)
      </button>
    </aside>
  );
}

export default Cart;