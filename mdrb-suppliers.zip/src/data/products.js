export default [
  {
    name: "Rice 25kg",
    price: 2000,
    image: "https://via.placeholder.com/150"
  },
  {
    name: "Cooking Oil 5L",
    price: 1200,
    image: "https://via.placeholder.com/150"
  },
  {
    name: "Wheat Flour 10kg",
    price: 800,
    image: "https://via.placeholder.com/150"
  },
  {
    name: "Lentils 2kg",
    price: 400,
    image: "https://via.placeholder.com/150"
  }
];