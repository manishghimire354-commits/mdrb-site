import React, { useState } from "react";
import Header from "./components/Header";
import ProductCard from "./components/ProductCard";
import Cart from "./components/Cart";
import products from "./data/products";

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    setCart((prev) => [...prev, product]);
  };

  const removeFromCart = (index) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header cartCount={cart.length} />
      <main className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((p, idx) => (
          <ProductCard key={idx} product={p} addToCart={addToCart} />
        ))}
      </main>
      <Cart cart={cart} removeFromCart={removeFromCart} />
    </div>
  );
}

export default App;